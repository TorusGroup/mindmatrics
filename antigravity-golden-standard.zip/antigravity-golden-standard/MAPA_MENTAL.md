# 🧠 Mapa Mental do Antigravity Golden Standard

> Esta é a representação visual da inteligência integrada do seu sistema. Use a extensão **Mermaid Editor** no VS Code para visualizar este arquivo.

```mermaid
graph TD
    %% Centro
    GS((Antigravity<br/>Golden Standard))

    %% Domínios
    BUS[Business & Strategy]
    MAR[Marketing & Growth]
    TEC[Tech & Product]
    COR[System Core]

    GS --> BUS
    GS --> MAR
    GS --> TEC
    GS --> COR

    %% Business Domain
    subgraph Business
        B_A[Agents: McKinsey, YC, GTM, Solo-Op]
        B_S[Skills: Finance, Pricing, Growth, Startup-Ops]
        B_W[Workflows: /finance-forecast, /gtm-playbook, /startup-ops]
        B_A --- B_S
        B_S --- B_W
    end
    BUS --- Business

    %% Marketing Domain
    subgraph Marketing
        M_A[Agents: Content Strategist]
        M_S[Skills: GEO]
        M_W[Workflows: /launch-strategy, /seo-geo-brief]
        M_A --- M_S
        M_S --- M_W
    end
    MAR --- Marketing

    %% Tech Domain
    subgraph Tech
        T_A[Agents: Cloud Arch, Security, UX, Product]
        T_S[Skills: Devbox, UX-Audit, Vuln, Wireframe]
        T_W[Workflows: /deploy-preflight, /ux-review, /wireframe-flow]
        T_A --- T_S
        T_S --- T_W
    end
    TEC --- Tech

    %% Core Domain
    subgraph Core
        C_A[Agents: Orchestrator, Prompt Spec]
        C_S[Skills: QMD-Isolation, Discovery, Catalog]
        C_W[Workflows: /init, /create, /debug, /test, /verify-setup]
        C_A --- C_S
        C_S --- C_W
    end
    COR --- Core

    %% Estilos
    style GS fill:#f96,stroke:#333,stroke-width:4px
    style BUS fill:#bbf,stroke:#333,stroke-width:2px
    style MAR fill:#bfb,stroke:#333,stroke-width:2px
    style TEC fill:#fbf,stroke:#333,stroke-width:2px
    style COR fill:#eee,stroke:#333,stroke-width:2px
    
    classDef business fill:#e1f5fe,stroke:#01579b;
    classDef marketing fill:#e8f5e9,stroke:#1b5e20;
    classDef tech fill:#f3e5f5,stroke:#4a148c;
    classDef core fill:#fafafa,stroke:#212121;
```

### 💡 Como ler este mapa:
1.  **Agentes** são os "cérebros" que executam as tarefas.
2.  **Skills** são as ferramentas e conhecimentos técnicos que os agentes possuem.
3.  **Workflows** são as sequências de comandos que você ativa no terminal para gerar resultados.

Tudo está interconectado através do **QMD (Memória Modular)**, garantindo que o conhecimento flua entre os departamentos sem perder a organização.

---
> [!TIP]
> No VS Code, pressione `Ctrl+Shift+V` para abrir o preview deste arquivo.
