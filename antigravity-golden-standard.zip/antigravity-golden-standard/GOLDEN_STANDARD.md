# Antigravity Golden Standard: Windows Native Blueprint 💎🦄

> O Framework de Inteligência Definitivo para Solo Founders e Equipes de Elite. 
> Este arquivo serve como um manual de "Self-Onboarding" para humanos e outros Agentes Antigravity.

---

## 🚀 Visão Geral
O Golden Standard transforma um diretório comum em um **Soberano de Inteligência**. Ele combina 25+ agentes especializados, memória modular (QMD) e fluxos de trabalho de alta performance otimizados para **Windows Native**.

---

## 🛠️ Pré-requisitos (Windows)

Para que tudo funcione perfeitamente, o ambiente nativo precisa de:
1.  **Visual Studio Code**.
2.  **Node.js & pnpm** (Instalado nativamente no Windows).
3.  **Python 3.12+** (Instalado nativamente no Windows).
4.  **VS Code Extensions**:
    -   `tomoyukim.mermaid-editor`
    -   `eamodio.gitlens`
    -   `antfu.iconify`

---

## 📥 Guia de Instalação Rápida (Para Novos Agentes)

Se você é um agente Antigravity assumindo este workspace, siga estes passos:

### 1. Inicializar o Ambiente
Certifique-se de que o terminal é o **PowerShell** ou **Command Prompt** (Native Windows).

### 2. Rodar o Setup de Intelligence
```powershell
# No PowerShell, injete a inteligência no diretório alvo:
./setup.ps1 -Target "Caminho/Para/Projeto" -ProjectName "Nome"
```

---

## 🏎️ O que este Setup oferece (Além de Código):

1. **Memória Semântica (QMD)**: Isolação de memória por projeto, evitando "confusão" entre contextos.
2. **Protocolo de Rastreabilidade**: Auditabilidade completa de cada plano e ação da IA.
3. **Esquadrão de Elite**: 25+ personas pre-configuradas (McKinsey, YC, Business Analyst).
4. **Workflows Turbo**: Comandos como `/init`, `/ship` e `/wireframe-flow` que automatizam horas de trabalho manual.
5. **DNA de Design**: Protocolos de estética premium (Glassmorphism, Dark Mode) integrados.

---

## 🏗️ Estrutura de Pastas
-   `.agent/agents/`: Onde mora a consciência (McKinsey, YC, Solo-Op, etc).
-   `.agent/skills/`: As competências técnicas compartilhadas.
-   `.agent/workflows/`: Os comandos turbo (`/init`, `/ship`, `/wireframe-flow`).
-   `setup.ps1`: Script para clonar este padrão para qualquer nova pasta.

---
**Status: 100% OPERACIONAL (Windows Native)** 🥂✨
