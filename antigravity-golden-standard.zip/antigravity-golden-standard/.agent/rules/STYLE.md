# 🎨 STYLE.md - The Design DNA

> "Code like a product, design like an artist."

This file defines the high-level aesthetic and cognitive "vibe" for the Antigravity Golden Standard. Agents MUST adhere to these principles during "Vibe Coding" sessions.

## 🌈 Visual Soul
- **Palette**: Use deep zinc, slate, and charcoal for dark modes. Accents should be in vibrant but professional HSL values (e.g., Electric Blue #0070f3, Emerald #0070f3).
- **Aesthetics**: Glassmorphism (blur, transparency), subtle gradients, and high contrast. 
- **Typography**: Prioritize Inter, Roboto, or system sans-serif. Use high-contrast font weights for hierarchy.

## 🛠️ Code Vibe
- **Frameworks**: Prioritize Next.js 15, React 19, and Tailwind CSS v4.
- **Philosophy**: "Vercel Engineering" style — clean, performance-first, minimal waterfalls, and server-side first.
- **Icons**: Use Lucide React or Simple Icons. No generic SVG placeholders.

## 🧠 Cognitive Vibe
- **Proactiveness**: Work should feel "magical". Don't ask for permission for minor formatting. Propose scripts for everything complex.
- **Traceability**: Always leave a paper trail. If a decision was made for performance, document it in an artifact.

---
> 🤖 **Mission**: Build interfaces that WOW the user and code that scales silently.
