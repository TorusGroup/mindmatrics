---
description: // turbo
---

# 📝 Workflow: SEO/GEO Brief (AI Visibility)

Use this workflow to generate content that AI models (Gemini, ChatGPT) will love to cite.

## Step 1: Semantic Research
1. **Topic Analysis**: `@content-strategist` identifies the "Semantic Core" of the topic.
2. **Authority Audit**: Find key questions that AI tools are currently answering.

## Step 2: Brief Generation
3. **Structured Brief**: Generate a markdown brief with clear headings, lists, and "Quote-Ready" insights.
4. **Citation Check**: `@content-strategist` verifies if the content structure follows the "Citation Stack" framework.

---
> 🤖 **Output**: A content brief optimized for both Humans and AI.
