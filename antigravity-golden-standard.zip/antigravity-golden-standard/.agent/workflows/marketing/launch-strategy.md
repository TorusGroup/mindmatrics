---
description: // turbo-all
---

# 🚀 Workflow: Launch Strategy (The Big Bang)

Use this workflow to coordinate a multi-channel product launch.

## Step 1: Asset Preparation
1. **Content Suitcase**: `@content-strategist` generates launch posts, email drafts, and ad copy.
2. **Growth Prep**: `@growth-hacker` sets up the referral tracking and viral loops.

## Step 2: Channel Execution
3. **Multi-Channel Blast**: Plan for Product Hunt, X (Twitter), LinkedIn, and Reddit.
4. **GEO Boost**: Ensure all launch content is structured for AI citation.

## Step 3: Monitoring
5. **Real-time Funnel Audit**: `@growth-hacker` monitors conversion rates and bounce rates.

---
> 🚀 **Next**: Once live, run `/gtm-playbook` for the first 100 customers.
