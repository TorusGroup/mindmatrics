---
description: // turbo-all
---

# Workflow: /ship

This workflow performs the final pre-flight checks before delivery.

## Phase 1: Global Audit
1. **Security Scan**: Run `security_scan.py` (if available) or check for secrets.
2. **Quality Check**: Run full test suite and linting.

## Phase 2: Documentation
3. **Walkthrough**: Generate `walkthrough.md` with proof of work (recordings/screenshots).
4. **Changelog**: Update the project's changelog or README.

## Phase 3: Final Approval
5. **@orchestrator**: Final review of all criteria in `GEMINI.md`'s Final Checklist.
6. **Notify User**: Present the final results and request formal sign-off.
