---
description: // turbo
---

# Workflow: /feature

This workflow standardizes the development of a new feature.

## Phase 1: Contextual Planning
1. **@orchestrator**: Analyze the user's feature request.
2. **Memory Scan**: Search past projects for similar patterns.
   - Tool: `qmd_search` or `qmd_vsearch`.
3. **Plan Generation**: Create `task.md` and `implementation_plan.md`.

## Phase 2: Implementation
4. **@fullstack-dev**: Execute the proposed changes.
5. **Batch Scripting**: Propose changes as a single `.ps1` script for approval.

## Phase 3: Validation
6. **@qa-engineer**: Run unit and integration tests.
   - Command: `npm test`
7. **Verification**: Check for linting and security vulnerabilities.
