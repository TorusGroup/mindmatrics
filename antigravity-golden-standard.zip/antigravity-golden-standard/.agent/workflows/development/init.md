---
description: // turbo-all
---

# Workflow: /init

This workflow initializes a new project environment.

## Phase 1: Environment Setup
1. **System Check**: Verify Node.js, Bun, and Git installation.
2. **Project Bootstrap**: Run `npm init -y` or `bun init -y` if a package.json is missing.
3. **Antigravity Injection**: Copy the `.agent` folder to the target directory.

## Phase 2: Knowledge Indexing
4. **QMD Setup**: Add the current path to QMD collections.
   - Command: `qmd collection add . --name current-project`
5. **Initial Embed**: Generate initial embeddings for documentation.
   - Command: `qmd embed`

## Phase 3: Baseline Verification
6. **Integrity Check**: Run `/verify-setup` to ensure all agents are reachable.
