---
description: // turbo-all
---

# 🕹️ Workflow: Startup Ops (The Automated Office)

Use this workflow to architect the "Back-Office" of your solo startup.

## Step 1: Stack Definition
1. **Tooling Selection**: `@solo-operator` proposes the best versions of Clerk, Stripe, Resend, and CustomerOS for the project.
2. **Billing Architecture**: `@gtm-specialist` + `@solo-operator` design the billing tiers and price points.

## Step 2: Integration Blueprint
3. **The Logic Map**: Generate a diagram showing how events flow between tools (e.g., Sign-up -> Welcome Email -> CRM Log).
4. **Implementation Script**: Generate the necessary environment variable placeholders and initialization steps.

## Step 3: Founder P&L
5. **Financial Forecast**: `@yc-visionary` audits the cost vs. revenue potential of the automated ops.

---
> 🤖 **Next**: Once approved, run `/init` to start building the core application.
