---
description: // turbo-all
---

# 🛫 Workflow: GTM Playbook (Zero to 100)

Use this workflow to execute a "Problem-First" market entry.

## Step 1: Foundation
1. **ICP Lockdown**: `@gtm-specialist` defines the target audience and their core "Pain Point".
2. **Pricing Model**: `@solo-operator` + `@yc-visionary` set up the initial monetization logic.

## Step 2: Acquisition
3. **Channel Selection**: Pick 2 high-leverage channels (e.g., Cold Email + Content).
4. **Experiment Design**: `@growth-hacker` creates the first 3 HADI cycle experiments.

## Step 3: Scaling
5. **The Aha! Moment**: Audit the onboarding to ensure users reach value in < 30 seconds.

---
> 📈 **Next**: Run `/finance-forecast` once the first 10 customers are acquired.
