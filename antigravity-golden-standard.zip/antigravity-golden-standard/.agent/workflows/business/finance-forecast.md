---
description: // turbo-all
---

# 📊 Workflow: Finance Forecast (Unit Economics)

Use this workflow to stress-test your growth and revenue assumptions.

## Step 1: Inputs
1. **Unit Economics Setup**: `@solo-operator` inputs the expected CAC and LTV targets.
2. **Growth Assumptions**: `@growth-hacker` adds expected conversion rates per channel.

## Step 2: Projections
3. **The 12-Month Run**: Generate a step-by-step projection of revenue, costs (API tokens, infrastructure), and churn.
4. **YC/VC Audit**: `@yc-visionary` audits the model for "VC-Backable" growth curves.

---
> 💰 **Output**: A comprehensive financial model saved to `docs/strategy/FINANCE.md`.
