---
description: // turbo
---

# 🧠 Workflow: UX Review (Psychological Audit)

Use this workflow to transform a "functional" UI into a "premium" experience.

## Step 1: The First Glance
1. **Salience Audit**: `@ux-psychologist` creates a "Heatmap" of the current UI (simulated).
2. **Cognitive Load Test**: Identify areas where the user might feel overwhelmed.

## Step 2: Path to Conversion
3. **The Hook Audit**: Check if the "Aha! Moment" is reached in < 30 seconds.
4. **Friction Hunt**: Find every redundant click or confusing label.

## Step 3: Aurora Alignment
5. **Vibe Check**: Ensure the Glassmorphism, Typography, and Animations align with the "Aurora" Design DNA.
6. **Accessibility Check**: Verify WCAG compliance and mobile responsiveness.

---
> 🎨 **Output**: A prioritized list of "Quick Wins" and "Strategic Changes" for the UI.
