---
description: // turbo-all
---

# 🛫 Workflow: Deploy Preflight (The Triple Audit)

Use this workflow before any code is pushed to production.

## Step 1: Security Audit
1. **Infiltration Test**: `@security-auditor` scans for vulnerabilities and prompt injection points.
2. **Secret Check**: Verify that no keys are in the codebase.

## Step 2: Infrastructure & Perf
3. **Architecture Check**: `@cloud-architect` audits the deployment config (Vercel/Docker) for scalability.
4. **Performance Audit**: Run lighthouse/bundle analysis to ensure < 1s Load Time.

## Step 3: UX & Business
5. **Final UX Review**: `@ux-psychologist` checks for conversion friction and visual bugs.
6. **Unit Economics Check**: `@yc-visionary` confirms if the feature supports the growth/revenue targets.

---
> 🚀 **Ready**: Once all agents give the "Green Light", proceed to `git push production`.
