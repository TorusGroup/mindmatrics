---
description: // turbo-all
---

# 📐 Workflow: Wireframe Flow (Visual Map to Build)

Use this workflow to transform a text feature description into a build-ready visual map.

## Step 1: Logic Extraction
1. **User Journey**: `@product-designer` extracts the "Happy Path" from the user request.
2. **Screen Logic**: Identify the main screens and modules needed (e.g., Landing, Dashboard, Profile).

## Step 2: Mermaid Generation
3. **Visual Wireframe**: Generate a Mermaid `flowchart` with subgraphs representing the planned screens.
4. **Interaction Map**: Generate a Mermaid `sequenceDiagram` showing how data flows between the user and the system.

## Step 3: Architecture Audit
5. **Technical Feasibility**: `@cloud-architect` audits the flow for potential infrastructure bottlenecks.
6. **UX Refinement**: `@ux-psychologist` suggests 3 improvements to reduce cognitive load in the flow.

---
> 🤖 **Output**: Visual documentation saved to `docs/architecture/WIREFRAMES.md`.
