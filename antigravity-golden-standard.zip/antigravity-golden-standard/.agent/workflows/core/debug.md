---
description: // turbo-all
---

# 🐞 Workflow: Debug (Systematic Investigation)

Use this workflow when facing a technical blocker or bug.

## Step 1: Reproduction
1. **Error Analysis**: Capture logs and stack traces.
2. **Context Mapping**: `@orchestrator` identifies affected files.

## Step 2: Root Cause
3. **The 5-Whys**: Systematically narrow down the cause from symptom to source.
4. **Fix Strategy**: Plan the fix with a focus on preventing regression.

---
> 🛡️ **Rule**: Never fix without a passing test first.
