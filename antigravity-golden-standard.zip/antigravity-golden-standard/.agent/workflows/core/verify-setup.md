---
description: // turbo-all
---

# 🛡️ Workflow: Verify Setup (The Final Health Check)

Use this workflow immediately after installing the Golden Standard in a new workspace.

## Step 1: Connectivity Check
1. **Agent Ping**: `@orchestrator` pings `@yc-visionary` and `@fullstack-dev` to ensure they respond.
2. **Environment Check**: Verify if `.env` exists and if critical keys (GEMINI_API_KEY, etc.) are present (but don't show them).

## Step 2: Tooling & Devbox
3. **Devbox Audit**: Check if `devbox.json` is valid and if the local shell can resolve standard commands.
4. **Memory Check**: `@orchestrator` queries the QMD collection for the project name to verify isolation.

## Step 3: Readiness Report
5. **System Green Light**: If all pass, `@orchestrator` generates a "Ready to Launch" report.

---
> 🚀 **Verified**: Your Golden Standard is operational. Run `/init` to begin.
