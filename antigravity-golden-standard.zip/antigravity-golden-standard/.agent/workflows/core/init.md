---
description: // turbo-all
---

# 🚀 Workflow: Init (Project Initialization)

Sets up the foundational structure of a new Golden Standard project.

## Step 1: File System
1. **Dir Structure**: Create the standard folders (`src`, `tests`, `.agent`, `docs`).
2. **Config**: Generate `.env.example`, `package.json`, and `tsconfig.json`.

## Step 2: Foundation
3. **Golden DNA**: Apply the base CSS/JS utilities.
4. **Git Init**: Initialize the repository.

---
> 🤖 **Next**: Run `/create` to start the first feature.
