---
description: // turbo-all
---

# 🛫 Workflow: Deploy (Production Release)

The standard procedure for releasing code to production.

## Step 1: Pre-flight
1. **Audit**: Run `/deploy-preflight` to ensure Security, Cloud, and UX sign-off.
2. **Build**: Verify that the production build passes locally.

## Step 2: Push
3. **Git Push**: Execute the git push to the production branch.
4. **Health Check**: Monitor logs for any immediate failures.

---
> 🚩 **Guardrail**: If any preflight audit fails, the deploy is automatically aborted.
