---
description: // turbo-all
---

# 🎨 Workflow: UI-UX Pro Max (Premium Interface)

The workflow for creating "WOW" interfaces.

## Step 1: Design Thinking
1. **Wireframe**: Run `/wireframe-flow` for the screen.
2. **Vibe Check**: `@ux-psychologist` audits for Aurora alignment.

## Step 2: Delivery
3. **CSS Layer**: Implement the glassmorphic tokens and animations.
4. **Final Audit**: Run `/ux-review` on the live interface.

---
> ✨ **Result**: A premium, state-of-the-art web interface.
