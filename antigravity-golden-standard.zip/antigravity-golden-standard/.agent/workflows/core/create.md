---
description: // turbo-all
---

# 🔨 Workflow: Create (New Application)

The main entry point for building a new software project.

## Step 1: Discovery
1. **App Metadata**: Define app name, target audience, and core problem.
2. **Agentic Selection**: `@orchestrator` selects the best specialists for the task.

## Step 2: Planning
3. **The implementation_plan**: Generate a phased plan with clear milestones.
4. **Approval**: Wait for user sign-off before coding.

---
> 🤖 **Reference**: Follow the App Builder skill for detailed execution logic.
