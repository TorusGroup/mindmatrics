---
description: // turbo-all
---

# 🧠 Workflow: Brainstorm (Structured Ideation)

Use this workflow to explore multiple options before implementation.

## Step 1: Deep Discovery
1. **Socratic Questioning**: `@orchestrator` asks 3 strategic questions to define scope and constraints.
2. **Market Scan**: `@business-analyst` provides 3 references or trends.

## Step 2: Option Generation
3. **The Strategy Board**: `@mckinsey-consultant` + `@yc-visionary` propose two distinct approaches (e.g., Lean vs. Scale).
4. **Technical Feasibility**: `@orchestrator` audits the complexity of both options.

---
> 🚀 **Result**: A selected path and a high-level plan.
