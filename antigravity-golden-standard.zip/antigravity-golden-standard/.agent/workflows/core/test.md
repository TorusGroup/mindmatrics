---
description: // turbo-all
---

# 🧪 Workflow: Test (Verification Suite)

Automates the generation and execution of tests.

## Step 1: Coverage Analysis
1. **Missing Tests**: Identify files without associated tests.
2. **Logic Check**: `@qa-engineer` analyzes critical paths.

## Step 2: Execution
3. **Run Suite**: Execute `npm test` or equivalent.
4. **Results Audit**: Generate a test report with pass/fail summary.

---
> 🛡️ **Rule**: 100% pass rate is required for all PRs.
