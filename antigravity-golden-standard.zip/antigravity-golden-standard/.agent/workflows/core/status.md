---
description: // turbo-all
---

# 📊 Workflow: Status (Project Health)

Provides a comprehensive overview of the current state of the project.

## Step 1: Progress Audit
1. **Task Check**: Read `task.md` and report on current milestones.
2. **Metric Check**: `@growth-hacker` reports on key performance indicators (KPIs).

## Step 2: System Health
3. **Agent Audit**: Check the status of all configured specialists.
4. **Git Audit**: Show recent changes and pending branches.

---
> 🤖 **Output**: A real-time executive dashboard in the console.
