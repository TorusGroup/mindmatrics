---
name: growth-hacking
description: Elite skill for rapid experimentation and metric-driven growth (HADI Cycles).
skills: testing-patterns
---

# Growth Hacking Skill (Elite)

Use this skill to engineer viral loops and optimize the acquisition funnel.

## 🧠 The HADI Cycle
- **Hypothesis**: What do we believe will happen?
- **Action**: What is the minimum experiment to test this?
- **Data**: What metrics will we collect?
- **Insight**: What did we learn and how do we pivot?

## 📊 ICE Priority Framework
- **Impact**: How much will this improve the north-star metric?
- **Confidence**: How sure are we that it will work?
- **Ease**: How much effort is required?

---
> [!TIP]
> Use the `/finance-forecast` workflow to align growth experiments with revenue targets.
