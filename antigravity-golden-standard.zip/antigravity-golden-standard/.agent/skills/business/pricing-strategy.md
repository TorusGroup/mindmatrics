---
name: pricing-strategy
description: Optimization of monetization models (Usage-based, Tiered, Outcome-based).
skills: architecture
---

# Pricing Strategy Skill (Elite)

Use this skill to maximize revenue and product-market fit.

## 💰 Monetization Archetypes
- **Tiered SaaS**: Basic, Pro, Enterprise (Best for predictability).
- **Usage-Based**: Pay-per-token or pay-per-seat (Best for AI products).
- **Outcome-Based**: Fee based on value delivered (High risk/High reward).

## 🛡️ Guardrails
- Avoid "Race to the bottom" pricing.
- Always provide a free tier or trial for the "Aha! Moment".

---
> [!TIP]
> Use the `/startup-ops` workflow to implement these price points in Stripe.
