---
name: startup-operations
description: Practical logic for automated solo-founder operations (Payments, Auth, Email).
skills: financial-modeling, pricing-strategy
---

# Startup Operations Skill (Solo Founder Elite)

Use this skill to design the automated back-office of a solo-run project.

## 🛠️ Integration Logic

### 1. Authentication (Clerk)
- **User Personas**: Define `Admin`, `Member`, and `Guest` roles.
- **Onboarding Flow**: Auto-triggering a welcome email via Resend after Clerk sign-up.

### 2. Payments & Billing (Stripe)
- **Pricing Integration**: Connecting `pricing-strategy` choices to Stripe product IDs.
- **Usage Tracking**: Logic for reporting usage (e.g., API calls, storage) to Stripe for billing.
- **Success Triggers**: Auto-provisioning resources after Stripe payment confirmation.

### 3. Communication (Resend)
- **Transactional Triggers**: Password resets, payment failures, and system alerts.
- **Marketing Integration**: Sending high-value insights (from `@content-strategist`) to leads.

---
> [!TIP]
> Use the `/startup-ops` workflow to implement these price points in Stripe.
