---
name: financial-modeling
description: Advanced skill for SaaS and AI unit economics (CAC, LTV, Churn).
skills: architecture
---

# Financial Modeling Skill (Elite)

Use this skill to build sustainable business models for solo startups.

## 📈 Key Metrics
- **CAC (Customer Acquisition Cost)**: Total spend / New customers.
- **LTV (Lifetime Value)**: Average revenue per user * Average lifespan.
- **LTV/CAC Ratio**: Aim for > 3:1 for a healthy startup.
- **Payback Period**: How many months to recover the CAC.

## 🛠️ Modeling Scenarios
- **Conservative**: Focus on organic growth and high retention.
- **Aggressive**: Focus on paid acquisition and rapid scale.

---
> [!IMPORTANT]
> In solo startups, the "Burn Rate" should be kept near zero through automation.
