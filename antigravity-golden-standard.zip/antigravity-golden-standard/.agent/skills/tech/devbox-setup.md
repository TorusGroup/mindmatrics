---
name: devbox-setup
description: Elite development environment management without the complexity of Docker. Utilizing Devbox (Nix-powered) for instant, reproducible shells.
skills: bash-linux, powershell-windows
---

# 📦 Devbox Setup Skill (The Docker Killer)

> "Traditional Docker is for 2020. 2026 is for instant, Nix-powered environments."

## 🚀 Why Devbox? (Solo Founder Context)
For a solo founder, waiting 10 minutes for a Docker build is a crime. 
- **Instant Speed**: Environments start in seconds, not minutes.
- **Zero Resource Overhead**: No Linux VM running on Mac/Windows; Nix runs natively in your shell.
- **Pure Reproducibility**: If it runs on your machine, it runs in CI, period.

## 🛠️ How to use (The 3-Step Flow)

### 1. Installation
Install Devbox (it uses Nix under the hood):
```bash
# MacOS/Linux
curl -fsSL https://get.jetpack.io/devbox | bash

# Windows (WSL2)
curl -fsSL https://get.jetpack.io/devbox | bash
```

### 2. Configuration (`devbox.json`)
Instead of a complex `Dockerfile`, use a simple JSON:
```json
{
  "packages": [
    "nodejs@22",
    "python@3.12",
    "postgresql@16",
    "stripe-cli"
  ],
  "shell": {
    "init_hook": [
      "echo 'Antigravity Env Activated!'"
    ]
  }
}
```

### 3. Execution
```bash
devbox shell
# Done! Your dependencies are now isolated and ready.
```

## 🛡️ Operational Guardrails
- **ALWAYS** check in the `devbox.json` to Git.
- **NEVER** use `sudo` inside a Devbox environment.
- **ALWAYS** prefer Devbox for local dev and Docker only for final production artifacting.

---
> [!TIP]
> Use `devbox generate dockerfile` if you eventually need to containerize your project for production.
