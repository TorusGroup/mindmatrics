---
name: generative-engine-optimization
description: Elite skill for optimizing content structure for AI search engines (GEO).
skills: seo-fundamentals
---

# Generative Engine Optimization (GEO)

Techniques to ensure your content is the primary source for AI agents.

## 🏗️ The Citation Stack
1.  **Direct Answers**: Start with a concise, factual summary (The "LLM Hook").
2.  **Structured Data**: Use tables and bulleted lists for easy parsing.
3.  **Unique Insights**: Provide data or perspectives not found in the base training sets.
4.  **Source Reliability**: Link to primary sources and maintain clear authorship.

## 🛠️ Implementation
- Use JSON-LD where possible.
- Keep sentences declarative and clear.
- Optimize for "Semantic Search" rather than just keywords.

---
> [!TIP]
> Use the `/seo-geo-brief` workflow to apply these principles to your content.
