---
name: qmd-isolation
description: Protocol for managing isolated memory collections per project using QMD MCP.
skills: architecture, database-design
---

# QMD Isolation & Memory Management (Elite)

Use this skill to ensure that project knowledge is persistent, searchable, and strictly isolated.

## 🧠 Memory Philosophy
An AI agent is only as good as its context. By isolating memory, we prevent "knowledge drift" between unrelated projects.

## 🛠️ Operational Protocol

### 1. Initializing a Collection
When starting a new project, always check for an existing QMD collection:
```bash
# Check if collection exists for current project name
# If not, create it
qmd collection add <project-name>
```

### 2. Indexing Context
Periodically index critical documents to the vector store:
- `implementation_plan.md` (Strategic intent)
- `ARCHITECTURE.md` (System design)
- Key architectural decisions (ADRs)

### 3. Contextual Retrieval
Before starting a complex task, query the project-specific collection:
- "What were the design decisions for the authentication flow?"
- "Retrieve the database schema from the discovery phase."

## 🛡️ Guardrails
- **NEVER** index secrets or API keys.
- **ALWAYS** scope search queries to the current project collection unless global patterns are explicitly requested.
- **NEVER** mix corporate strategy (McKinsey) memory with technical implementation details if they belong to different domains.

---
> [!IMPORTANT]
> The `setup.ps1` script automatically triggers the first `qmd collection add` command.
