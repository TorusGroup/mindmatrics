param (
    [Parameter(Mandatory = $true)]
    [string]$SkillName,
    
    [Parameter(Mandatory = $true)]
    [string]$Category
)

$repoUrl = "https://raw.githubusercontent.com/sickn33/antigravity-awesome-skills/main"
$targetBase = "d:/ANTIGRAVITY_SETUP/antigravity-golden-standard/.agent/skills"
$skillPath = "$targetBase/$Category/$SkillName"

Write-Host "🚀 Importing Skill: $SkillName into $Category..."

# Ensure target folder exists
New-Item -ItemType Directory -Force -Path $skillPath

# 1. Download SKILL.md
$skillMdUrl = "$repoUrl/skills/$Category/$SkillName/SKILL.md"
try {
    Invoke-RestMethod -Uri $skillMdUrl -OutFile "$skillPath/SKILL.md"
    Write-Host "✅ SKILL.md imported."
}
catch {
    Write-Error "❌ Could not find SKILL.md at $skillMdUrl"
    exit 1
}

# 2. Check for optional scripts/references (Heuristic - would need recursive logic or index for 100% accuracy)
# For now, we assume standard structure as per catalog.
Write-Host "✨ Skill $SkillName is now part of the Golden Standard."
