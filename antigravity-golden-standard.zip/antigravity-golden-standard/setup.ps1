param (
    [string]$Target,
    [string]$ProjectName
)
$ErrorActionPreference = "Stop"
Write-Host "--- Antigravity Golden Standard: Windows Native Installation ---"

# 1. Create Target Directory
if (!(Test-Path $Target)) {
    Write-Host "Creating target directory: $Target"
    New-Item -ItemType Directory -Path $Target -Force | Out-Null
}

# 2. Clone .agent folder
$SourceAgent = Join-Path $PSScriptRoot ".agent"
$DestAgent = Join-Path $Target ".agent"
Write-Host "Cloning Intelligence Squad..."
Copy-Item -Path $SourceAgent -Destination $DestAgent -Recurse -Force

# 3. Initialize Standard Files
Write-Host "Initializing Foundation..."
$Files = @(".env.example.md", "GEMINI.md", "GOLDEN_STANDARD.md")
foreach ($f in $Files) {
    if (Test-Path (Join-Path $PSScriptRoot $f)) {
        Copy-Item (Join-Path $PSScriptRoot $f) (Join-Path $Target $f) -Force
    }
}

# 4. Create initial task.md
$TaskPath = Join-Path $Target "task.md"
if (!(Test-Path $TaskPath)) {
    $c = "# Task: $ProjectName Initialization`n"
    $c += "Objective: Start the project using the Antigravity Golden Standard.`n`n"
    $c += "## Phase 1: Setup`n"
    $c += "- [x] Install Golden Standard via setup.ps1`n"
    $c += "- [ ] Configure .env with API keys`n"
    $c += "- [ ] Execute /init workflow`n"
    $c | Out-File -FilePath $TaskPath -Encoding utf8
}

Write-Host "SUCCESS! Golden Standard installed in $Target"
Write-Host "Next step: Open the folder in VS Code and run /verify-setup"
