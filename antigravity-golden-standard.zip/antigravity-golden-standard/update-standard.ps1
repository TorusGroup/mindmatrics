<#
.SYNOPSIS
    Antigravity Golden Standard: Intelligence Sync Engine
.DESCRIPTION
    Pulls the latest updates from the Master Template to an active project.
    Use this to get new agents, skills, or workflows without breaking the project code.
#>

param (
    [Parameter(Mandatory = $true)]
    [string]$TargetProject
)

$MasterTemplate = $PSScriptRoot
$TargetAgentPath = Join-Path $TargetProject ".agent"

if (!(Test-Path $TargetAgentPath)) {
    Write-Error "Target project does not have an .agent folder at $TargetAgentPath"
    exit 1
}

Write-Host "🔄 Syncing Intelligence from Golden Master..." -ForegroundColor Cyan

# Define items to sync (keep it safe)
$Items = @("agents", "skills", "workflows")

foreach ($item in $Items) {
    $Src = Join-Path (Join-Path $MasterTemplate ".agent") $item
    $Dst = Join-Path $TargetAgentPath $item
    
    Write-Host "Updating $item..." -ForegroundColor Gray
    Copy-Item -Path "$Src\*" -Destination $Dst -Recurse -Force
}

Write-Host "`n✅ Sync Complete! Your intelligence is now up-to-date.`n" -ForegroundColor Green
